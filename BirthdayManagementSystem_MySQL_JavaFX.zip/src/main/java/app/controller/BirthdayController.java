
package app.controller;

import app.model.Birthday;
import app.util.DBConnection;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class BirthdayController {
    @FXML
    private TextField nameField;
    @FXML
    private DatePicker birthdatePicker;
    @FXML
    private TextArea notesField;

    @FXML
    public void addBirthday() {
        String name = nameField.getText();
        String birthdate = birthdatePicker.getValue().toString();
        String notes = notesField.getText();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO birthdays (name, birthdate, notes) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, birthdate);
            stmt.setString(3, notes);
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
