
package app.model;

public class Birthday {
    private String name;
    private String birthdate;
    private String notes;

    public Birthday(String name, String birthdate, String notes) {
        this.name = name;
        this.birthdate = birthdate;
        this.notes = notes;
    }

    public String getName() { return name; }
    public String getBirthdate() { return birthdate; }
    public String getNotes() { return notes; }
}
