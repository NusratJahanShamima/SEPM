
CREATE DATABASE IF NOT EXISTS birthday_db;
USE birthday_db;

CREATE TABLE IF NOT EXISTS birthdays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    birthdate DATE NOT NULL,
    notes TEXT
);
